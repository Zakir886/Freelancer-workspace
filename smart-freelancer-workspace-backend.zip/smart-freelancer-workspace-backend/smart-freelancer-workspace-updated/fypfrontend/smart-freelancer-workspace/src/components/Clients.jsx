import React, { useState } from 'react';
import { Icon } from '../Icons.jsx';
import { Modal, Pill, EmptyState } from './shared.jsx';
import { avStyle, initials, money, invTotal, fmtDate, iso } from '../utils.js';
import { PSTAT, ISTAT } from '../data.js';

export function ClientsView({ clients, projects, invoices, onAdd, onOpen }) {
  const [q, setQ] = useState('');
  const rows = clients.filter(c => (c.name + c.company + c.email).toLowerCase().includes(q.toLowerCase()));
  const billed = id => invoices.filter(i => i.clientId === id).reduce((s, i) => s + invTotal(i), 0);

  return (
    <React.Fragment>
      <div className="view-head">
        <div>
          <h2 className="view-title">Clients</h2>
          <p className="view-sub">{clients.length} people · {clients.filter(c => c.status === 'active').length} currently active</p>
        </div>
        <div className="view-actions">
          <div className="vsearch"><Icon name="search" size={15} />
            <input placeholder="Search clients…" value={q} onChange={e => setQ(e.target.value)} />
          </div>
          <button className="btn btn-primary" onClick={onAdd}><Icon name="plus" size={15} />Add client</button>
        </div>
      </div>
      <div className="panel">
        {rows.length === 0 ? <EmptyState q={q} onClear={() => setQ('')} /> : (
          <div className="table-wrap"><table className="table">
            <thead><tr><th>Client</th><th>Email</th><th>Phone</th><th>Projects</th><th>Lifetime billed</th><th>Status</th></tr></thead>
            <tbody>
              {rows.map(c => (
                <tr key={c.id} onClick={() => onOpen(c.id)}>
                  <td>
                    <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
                      <span className="avatar" style={avStyle(c.name)}>{initials(c.name)}</span>
                      <span className="td-main"><b>{c.name}</b><span className="td-sub">{c.company}</span></span>
                    </div>
                  </td>
                  <td style={{ color: 'var(--ink-soft)' }}>{c.email}</td>
                  <td style={{ color: 'var(--ink-soft)' }}>{c.phone}</td>
                  <td className="num">{projects.filter(p => p.clientId === c.id).length}</td>
                  <td className="num"><b>{money(billed(c.id))}</b></td>
                  <td>
                    {c.status === 'active'
                      ? <span className="pill st-green"><i></i>Active</span>
                      : <span className="pill st-neutral"><i></i>Idle</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table></div>
        )}
      </div>
    </React.Fragment>
  );
}

export function ClientModal({ init, onClose, onSave }) {
  const [f, setF] = useState(init
    ? { name: init.name, company: init.company, email: init.email, phone: init.phone, status: init.status }
    : { name: '', company: '', email: '', phone: '', status: 'active' });
  const [err, setErr] = useState('');
  const set = k => e => setF({ ...f, [k]: e.target.value });

  const save = () => {
    if (!f.name.trim()) return setErr('A client name is required.');
    if (!f.email.includes('@')) return setErr('Please enter a valid email address.');
    onSave({ ...f, id: init ? init.id : null, since: init ? init.since : iso(new Date()) });
  };

  return (
    <Modal onClose={onClose} width={540}>
      <div className="mod-head">
        <h3 className="mod-title">{init ? 'Edit client' : 'Add a new client'}</h3>
        <button className="mod-x" onClick={onClose}><Icon name="x" size={17} /></button>
      </div>
      <div className="mod-body">
        {err && <div className="form-err"><Icon name="alert" size={15} />{err}</div>}
        <div className="frow">
          <div className="field"><label>Full name *</label>
            <input className="input" placeholder="e.g. Amara Okafor" value={f.name} onChange={set('name')} autoFocus /></div>
          <div className="field"><label>Company</label>
            <input className="input" placeholder="e.g. Bloom Beauty Co." value={f.company} onChange={set('company')} /></div>
        </div>
        <div className="frow">
          <div className="field"><label>Email *</label>
            <input className="input" placeholder="name@company.com" value={f.email} onChange={set('email')} /></div>
          <div className="field"><label>Phone</label>
            <input className="input" placeholder="+1 555 000 0000" value={f.phone} onChange={set('phone')} /></div>
        </div>
        <div className="field"><label>Status</label>
          <select className="input" value={f.status} onChange={set('status')}>
            <option value="active">Active — currently working together</option>
            <option value="idle">Idle — no ongoing work</option>
          </select>
        </div>
      </div>
      <div className="mod-foot">
        <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
        <button className="btn btn-primary" onClick={save}>{init ? 'Save changes' : 'Add client'}</button>
      </div>
    </Modal>
  );
}

export function ClientDrawer({ client, projects, invoices, tasks, onClose, onEdit, onDelete, goProjectTasks, openInvoice }) {
  const cp = projects.filter(p => p.clientId === client.id);
  const ci = invoices.filter(i => i.clientId === client.id).sort((a, b) => b.issued.localeCompare(a.issued));
  const billed = ci.reduce((s, i) => s + invTotal(i), 0);
  const tCount = cp.reduce((s, p) => s + tasks.filter(t => t.projectId === p.id && t.status !== 'done').length, 0);

  return (
    <div className="drawer-ovl" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}>
      <aside className="drawer" onMouseDown={e => e.stopPropagation()}>
        <div className="dr-head">
          <span className="avatar" style={{ ...avStyle(client.name), width: 48, height: 48, fontSize: 15 }}>{initials(client.name)}</span>
          <div style={{ flex: 1 }}>
            <h3>{client.name}</h3>
            <div className="dr-co">{client.company}</div>
          </div>
          <button className="mod-x" onClick={onClose}><Icon name="x" size={17} /></button>
        </div>
        <div className="dr-body">
          <div className="dr-stats">
            <div className="dr-stat"><b>{cp.length}</b><span>Projects</span></div>
            <div className="dr-stat"><b>{ci.length}</b><span>Invoices</span></div>
            <div className="dr-stat"><b>{money(billed)}</b><span>Lifetime billed</span></div>
          </div>
          <div className="dr-contact"><span className="ci"><Icon name="mail" size={16} /></span>{client.email}</div>
          <div className="dr-contact"><span className="ci"><Icon name="phone" size={16} /></span>{client.phone}</div>
          <div className="dr-contact"><span className="ci"><Icon name="clock" size={16} /></span>Client since {fmtDate(client.since)} · {tCount} open task{tCount === 1 ? '' : 's'}</div>

          <div className="dr-sec">Projects</div>
          {cp.length === 0 && <p style={{ fontSize: 13, color: 'var(--ink-faint)' }}>No projects yet.</p>}
          {cp.map(p => (
            <div className="dr-row" key={p.id} onClick={() => goProjectTasks(p)}>
              <div><b>{p.title}</b><small>{money(p.budget)} budget</small></div>
              <Pill cfg={PSTAT[p.status]} />
            </div>
          ))}

          <div className="dr-sec">Invoices</div>
          {ci.length === 0 && <p style={{ fontSize: 13, color: 'var(--ink-faint)' }}>No invoices yet.</p>}
          {ci.map(i => (
            <div className="dr-row" key={i.id} onClick={() => openInvoice(i.id)}>
              <div><b>{i.number}</b><small>Due {fmtDate(i.due)}</small></div>
              <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                <b className="num">{money(invTotal(i))}</b>
                <Pill cfg={ISTAT[i.status]} />
              </div>
            </div>
          ))}
        </div>
        <div className="dr-foot">
          <button className="btn btn-ghost" onClick={onEdit}><Icon name="pencil" size={15} />Edit details</button>
          <button className="btn btn-danger" onClick={onDelete}><Icon name="trash" size={15} />Delete</button>
        </div>
      </aside>
    </div>
  );
}
