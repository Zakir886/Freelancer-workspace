import React, { useState, useRef } from 'react';
import { Icon } from '../Icons.jsx';
import { Modal } from './shared.jsx';
import { addDays, daysUntil, dueText } from '../utils.js';
import { PRIO } from '../data.js';

function TaskCard({ task, projectTitle, dragging, flash, onDragStart, onDragEnd, onEdit, onDelete, suppressClick }) {
  return (
    <div className={'tcard' + (dragging ? ' dragging' : '') + (flash ? ' pop' : '')}
      draggable
      onDragStart={e => onDragStart(e, task.id)}
      onDragEnd={() => { onDragEnd(); suppressClick.current = Date.now(); }}
      onClick={() => { if (Date.now() - suppressClick.current > 220) onEdit(task); }}>
      <button className="tdel" onClick={e => { e.stopPropagation(); onDelete(task); }}><Icon name="x" size={13} /></button>
      <p className={'ttitle' + (task.status === 'done' ? ' done' : '')}>{task.title}</p>
      <div className="tmeta">
        {projectTitle && <span className="tproj">{projectTitle}</span>}
        <span className={'chip-sm' + (daysUntil(task.due) < 0 ? ' over' : '')}>{dueText(task.due)}</span>
        <span className="tprio"><i style={{ background: PRIO[task.prio].color }} />{PRIO[task.prio].label}</span>
      </div>
    </div>
  );
}

export function TasksView({ projects, tasks, taskProject, setTaskProject, onNew, onEdit, onDelete, moveTask, flashId }) {
  const [over, setOver] = useState(null);
  const [dragId, setDragId] = useState(null);
  const suppressClick = useRef(0);
  const cols = [{ id: 'todo', label: 'To Do' }, { id: 'doing', label: 'In Progress' }, { id: 'done', label: 'Done' }];
  const list = tasks.filter(t => taskProject === 'all' || t.projectId === taskProject);
  const pTitle = id => { const p = projects.find(x => x.id === id); return p ? p.title : null; };

  return (
    <React.Fragment>
      <div className="view-head">
        <div>
          <h2 className="view-title">Task board</h2>
          <p className="view-sub">Drag cards between columns to update their status — it saves instantly.</p>
        </div>
        <div className="view-actions">
          <select className="select" value={taskProject} onChange={e => setTaskProject(e.target.value)}>
            <option value="all">All projects</option>
            {projects.map(p => <option key={p.id} value={p.id}>{p.title}</option>)}
          </select>
          <button className="btn btn-primary" onClick={() => onNew('todo')}><Icon name="plus" size={15} />New task</button>
        </div>
      </div>
      <div className="board">
        {cols.map(c => {
          const cards = list.filter(t => t.status === c.id);
          return (
            <div key={c.id}
              className={'kcol' + (over === c.id ? ' over' : '')}
              onDragOver={e => { e.preventDefault(); setOver(c.id); }}
              onDragLeave={e => { if (!e.currentTarget.contains(e.relatedTarget)) setOver(null); }}
              onDrop={e => {
                e.preventDefault();
                const id = e.dataTransfer.getData('text/plain') || dragId;
                if (id) moveTask(id, c.id);
                setOver(null); setDragId(null);
              }}>
              <div className="kcol-head">
                <span className={'kdot kd-' + c.id} /><h3>{c.label}</h3>
                <span className="kcount">{cards.length}</span>
                <button className="kadd" onClick={() => onNew(c.id)}><Icon name="plus" size={14} /></button>
              </div>
              <div className="kcards">
                {cards.map(t => (
                  <TaskCard key={t.id} task={t} projectTitle={pTitle(t.projectId)}
                    dragging={dragId === t.id} flash={flashId === t.id}
                    onDragStart={(e, id) => { e.dataTransfer.setData('text/plain', id); e.dataTransfer.effectAllowed = 'move'; setDragId(id); }}
                    onDragEnd={() => setDragId(null)}
                    onEdit={onEdit} onDelete={onDelete} suppressClick={suppressClick} />
                ))}
                {cards.length === 0 && <div className="kempty">Drop tasks here</div>}
              </div>
            </div>
          );
        })}
      </div>
    </React.Fragment>
  );
}

export function TaskModal({ init, status, projects, onClose, onSave }) {
  const [f, setF] = useState(init
    ? { title: init.title, projectId: init.projectId || '', prio: init.prio, due: init.due, status: init.status }
    : { title: '', projectId: '', prio: 'med', due: addDays(3), status: status || 'todo' });
  const [err, setErr] = useState('');
  const set = k => e => setF({ ...f, [k]: e.target.value });

  const save = () => {
    if (!f.title.trim()) return setErr('Give the task a short, clear title.');
    if (!f.projectId) return setErr('Choose the project this task belongs to.');
    onSave({ ...f, id: init ? init.id : null });
  };

  return (
    <Modal onClose={onClose} width={520}>
      <div className="mod-head">
        <h3 className="mod-title">{init ? 'Edit task' : 'New task'}</h3>
        <button className="mod-x" onClick={onClose}><Icon name="x" size={17} /></button>
      </div>
      <div className="mod-body">
        {err && <div className="form-err"><Icon name="alert" size={15} />{err}</div>}
        <div className="field"><label>Task title *</label>
          <input className="input" placeholder="e.g. Wireframe checkout flow" value={f.title} onChange={set('title')} autoFocus /></div>
        <div className="frow">
          <div className="field"><label>Project *</label>
            <select className="input" value={f.projectId} onChange={set('projectId')}>
              <option value="">Select a project…</option>
              {projects.map(p => <option key={p.id} value={p.id}>{p.title}</option>)}
            </select></div>
          <div className="field"><label>Priority</label>
            <select className="input" value={f.prio} onChange={set('prio')}>
              <option value="high">High</option><option value="med">Medium</option><option value="low">Low</option>
            </select></div>
        </div>
        <div className="frow">
          <div className="field"><label>Due date</label>
            <input className="input" type="date" value={f.due} onChange={set('due')} /></div>
          <div className="field"><label>Status</label>
            <select className="input" value={f.status} onChange={set('status')}>
              <option value="todo">To Do</option><option value="doing">In Progress</option><option value="done">Done</option>
            </select></div>
        </div>
      </div>
      <div className="mod-foot">
        <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
        <button className="btn btn-primary" onClick={save}>{init ? 'Save changes' : 'Add task'}</button>
      </div>
    </Modal>
  );
}
