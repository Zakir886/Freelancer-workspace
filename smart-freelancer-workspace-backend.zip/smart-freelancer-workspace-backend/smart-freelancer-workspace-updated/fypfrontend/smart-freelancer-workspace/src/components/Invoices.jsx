import React, { useState } from 'react';
import { Icon, Logo } from '../Icons.jsx';
import { Modal, Pill, DueChip, CountUp } from './shared.jsx';
import { money, invTotal, fmtDate, fmtDateLong, iso, addDays, daysUntil } from '../utils.js';
import { ISTAT } from '../data.js';

export function InvoicesView({ clients, projects, invoices, onAdd, onOpen, onMarkPaid, onDelete }) {
  const cName = id => { const c = clients.find(x => x.id === id); return c ? c.name : 'Former client'; };
  const pName = id => { const p = projects.find(x => x.id === id); return p ? p.title : 'Former project'; };
  const open = invoices.filter(i => i.status !== 'paid');
  const outSum = open.reduce((s, i) => s + invTotal(i), 0);
  const overdue = invoices.filter(i => i.status === 'overdue');
  const overSum = overdue.reduce((s, i) => s + invTotal(i), 0);
  const paid30 = invoices.filter(i => i.status === 'paid' && daysUntil(i.issued) >= -30);
  const paidSum = paid30.reduce((s, i) => s + invTotal(i), 0);

  return (
    <React.Fragment>
      <div className="view-head">
        <div>
          <h2 className="view-title">Invoices</h2>
          <p className="view-sub">{invoices.length} issued · {open.length} still open</p>
        </div>
        <div className="view-actions">
          <button className="btn btn-primary" onClick={onAdd}><Icon name="plus" size={15} />New invoice</button>
        </div>
      </div>
      <div className="stat-strip panel cols-3">
        <div className="stat">
          <span className="stat-k"><span className="sk-ico"><Icon name="banknote" size={15} /></span>Outstanding</span>
          <div className="stat-v"><CountUp value={outSum} moneyFormat /></div>
          <span className="stat-d">{open.length} awaiting payment</span>
        </div>
        <div className="stat">
          <span className="stat-k"><span className="sk-ico"><Icon name="alert" size={15} /></span>Overdue</span>
          <div className="stat-v" style={{ color: overdue.length ? 'var(--red)' : undefined }}><CountUp value={overSum} moneyFormat /></div>
          <span className="stat-d">{overdue.length ? <span style={{ color: 'var(--red)', fontWeight: 600 }}>{overdue.length} past due — chase today</span> : 'Nothing overdue'}</span>
        </div>
        <div className="stat">
          <span className="stat-k"><span className="sk-ico"><Icon name="check" size={15} /></span>Paid · last 30 days</span>
          <div className="stat-v"><CountUp value={paidSum} moneyFormat /></div>
          <span className="stat-d">{paid30.length} invoice{paid30.length === 1 ? '' : 's'} settled</span>
        </div>
      </div>
      <div className="panel" style={{ marginTop: 20 }}>
        <div className="table-wrap"><table className="table">
          <thead><tr><th>Invoice</th><th>Client</th><th>Project</th><th>Due</th><th className="ta-r">Amount</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {invoices.slice().sort((a, b) => b.issued.localeCompare(a.issued)).map(i => (
              <tr key={i.id} onClick={() => onOpen(i.id)}>
                <td><div className="td-main"><b>{i.number}</b><span className="td-sub">Issued {fmtDate(i.issued)}</span></div></td>
                <td><div className="td-main"><b>{cName(i.clientId)}</b></div></td>
                <td><div className="td-main"><b>{pName(i.projectId)}</b></div></td>
                <td><div className="td-main"><b>{fmtDate(i.due)}</b><DueChip date={i.due} /></div></td>
                <td className="ta-r num"><b style={{ fontSize: 14.5 }}>{money(invTotal(i))}</b></td>
                <td><Pill cfg={ISTAT[i.status]} /></td>
                <td>
                  <div className="row-acts">
                    <button className="mini-btn" title="Preview" onClick={e => { e.stopPropagation(); onOpen(i.id); }}><Icon name="eye" size={14} /></button>
                    {i.status !== 'paid' &&
                      <button className="mini-btn" title="Mark as paid" onClick={e => { e.stopPropagation(); onMarkPaid(i.id); }}><Icon name="check" size={14} /></button>}
                    <button className="mini-btn del" title="Delete" onClick={e => { e.stopPropagation(); onDelete(i); }}><Icon name="trash" size={14} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table></div>
      </div>
    </React.Fragment>
  );
}

export function InvoiceModal({ clients, projects, nextNumber, onClose, onCreate }) {
  const [clientId, setClientId] = useState('');
  const [projectId, setProjectId] = useState('');
  const [issued, setIssued] = useState(iso(new Date()));
  const [due, setDue] = useState(addDays(14));
  const [items, setItems] = useState([{ d: '', q: 1, r: '' }]);
  const [notes, setNotes] = useState('');
  const [err, setErr] = useState('');
  const total = items.reduce((s, it) => s + (Number(it.q) || 0) * (Number(it.r) || 0), 0);
  const setIt = (i, k, v) => setItems(items.map((it, x) => x === i ? { ...it, [k]: v } : it));

  const save = () => {
    if (!clientId) return setErr('Choose a client for this invoice.');
    if (!projectId) return setErr('Choose the project this invoice belongs to.');
    const its = items.filter(it => it.d.trim() && Number(it.q) > 0 && Number(it.r) > 0);
    if (!its.length) return setErr('Add at least one line item with a description, quantity and rate.');
    onCreate({ clientId, projectId, issued, due, items: its, notes: notes.trim(), status: 'pending' });
  };

  return (
    <Modal onClose={onClose} width={640}>
      <div className="mod-head">
        <div>
          <h3 className="mod-title">New invoice</h3>
          <p style={{ fontSize: 12.5, color: 'var(--ink-soft)', marginTop: 2 }}>{nextNumber}</p>
        </div>
        <button className="mod-x" onClick={onClose}><Icon name="x" size={17} /></button>
      </div>
      <div className="mod-body">
        {err && <div className="form-err"><Icon name="alert" size={15} />{err}</div>}
        <div className="frow">
          <div className="field"><label>Client *</label>
            <select className="input" value={clientId} onChange={e => { setClientId(e.target.value); setProjectId(''); }}>
              <option value="">Select a client…</option>
              {clients.map(c => <option key={c.id} value={c.id}>{c.name} — {c.company}</option>)}
            </select></div>
          <div className="field"><label>Project *</label>
            <select className="input" value={projectId} onChange={e => setProjectId(e.target.value)} disabled={!clientId}>
              <option value="">{clientId ? 'Select a project…' : 'Select client first…'}</option>
              {projects.filter(p => p.clientId === clientId).map(p => <option key={p.id} value={p.id}>{p.title}</option>)}
            </select></div>
          <div className="frow" style={{ gap: 14 }}>
            <div className="field"><label>Issue date</label>
              <input className="input" type="date" value={issued} onChange={e => setIssued(e.target.value)} /></div>
            <div className="field"><label>Due date</label>
              <input className="input" type="date" value={due} onChange={e => setDue(e.target.value)} /></div>
          </div>
        </div>
        <div className="field">
          <label>Line items</label>
          <div className="li-head"><span>Description</span><span>Qty</span><span>Rate ($)</span><span style={{ textAlign: 'right' }}>Amount</span><span></span></div>
          {items.map((it, i) => (
            <div className="li-row" key={i}>
              <input className="input" style={{ padding: '8px 10px' }} placeholder="e.g. Landing page design"
                value={it.d} onChange={e => setIt(i, 'd', e.target.value)} />
              <input className="input num" style={{ padding: '8px 10px' }} type="number" min="1" value={it.q}
                onChange={e => setIt(i, 'q', e.target.value)} />
              <input className="input num" style={{ padding: '8px 10px' }} type="number" min="0" placeholder="100"
                value={it.r} onChange={e => setIt(i, 'r', e.target.value)} />
              <span className="li-amt">{money((Number(it.q) || 0) * (Number(it.r) || 0))}</span>
              <button className="li-rm" title="Remove line" onClick={() => setItems(items.filter((_, x) => x !== i))}>
                <Icon name="minus" size={14} />
              </button>
            </div>
          ))}
          <button className="btn btn-ghost" style={{ marginTop: 4 }} onClick={() => setItems([...items, { d: '', q: 1, r: '' }])}>
            <Icon name="plus" size={14} />Add line item
          </button>
        </div>
        <div className="field"><label>Notes (optional)</label>
          <input className="input" placeholder="e.g. Payment within 14 days, thank you!" value={notes} onChange={e => setNotes(e.target.value)} /></div>
        <div className="inv-total-row">
          <span className="tt">Total</span>
          <span className="tv">{money(total)}</span>
        </div>
      </div>
      <div className="mod-foot">
        <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
        <button className="btn btn-primary" onClick={save}><Icon name="file" size={15} />Create invoice</button>
      </div>
    </Modal>
  );
}

export function InvoicePreview({ invoice, client, project, onClose, onMarkPaid }) {
  const total = invTotal(invoice);
  return (
    <Modal onClose={onClose} width={760}>
      <div className="mod-head">
        <h3 className="mod-title">Invoice preview</h3>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <button className="btn btn-ghost" onClick={() => window.print()}><Icon name="printer" size={15} />Print</button>
          {invoice.status !== 'paid' &&
            <button className="btn btn-brand" onClick={() => onMarkPaid(invoice.id)}><Icon name="check" size={15} />Mark as paid</button>}
          <button className="mod-x" onClick={onClose}><Icon name="x" size={17} /></button>
        </div>
      </div>
      <div className="mod-body">
        <div className="invoice-paper">
          <div className="inv-top">
            <div className="inv-brand">
              <Logo size={42} />
              <div>
                <b>Smart Freelancer Workspace</b>
                <span>sara@freelance.dev · +1 415 555 0107</span>
                <span>San Francisco, CA</span>
              </div>
            </div>
            <div>
              <div className="inv-h1">INVOICE</div>
              <div className="inv-no">{invoice.number}</div>
              <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 8 }}><Pill cfg={ISTAT[invoice.status]} /></div>
            </div>
          </div>
          <div className="inv-meta">
            <div>
              <div className="im-k">Billed to</div>
              <div className="im-v">{client ? client.name : 'Former client'}
                <span>{client ? client.company : ''}</span>
                <span>{client ? client.email : ''}</span>
              </div>
            </div>
            <div>
              <div className="im-k">Project</div>
              <div className="im-v">{project ? project.title : 'Former project'}</div>
            </div>
            <div>
              <div className="im-k">Issued on</div>
              <div className="im-v">{fmtDateLong(invoice.issued)}</div>
            </div>
            <div>
              <div className="im-k">Due by</div>
              <div className="im-v">{fmtDateLong(invoice.due)}</div>
            </div>
          </div>
          <table className="inv-table">
            <thead><tr><th>Description</th><th>Qty</th><th>Rate</th><th>Amount</th></tr></thead>
            <tbody>
              {invoice.items.map((it, i) => (
                <tr key={i}>
                  <td>{it.d}</td>
                  <td className="num">{it.q}</td>
                  <td className="num">{money(it.r)}</td>
                  <td>{money(it.q * it.r)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="inv-totals">
            <div className="tr"><span>Subtotal</span><span>{money(total)}</span></div>
            <div className="tr"><span>Tax (0%)</span><span>$0</span></div>
            <div className="tr grand"><span>Total due</span><span>{money(total)}</span></div>
          </div>
          {invoice.notes && <div className="inv-notes"><b>Notes — </b>{invoice.notes}</div>}
          <div className="inv-foot">
            <span>Thank you for your business — it’s a pleasure working with you.</span>
            <span>{invoice.number} · Smart Freelancer Workspace</span>
          </div>
        </div>
      </div>
    </Modal>
  );
}
