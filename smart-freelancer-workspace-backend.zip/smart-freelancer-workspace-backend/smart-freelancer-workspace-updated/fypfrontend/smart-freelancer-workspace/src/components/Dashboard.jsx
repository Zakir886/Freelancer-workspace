import React from 'react';
import { Icon } from '../Icons.jsx';
import { CountUp, DueChip } from './shared.jsx';
import EarningsChart from './EarningsChart.jsx';
import { invTotal, daysUntil, dueText, dlText } from '../utils.js';
import { PRIO } from '../data.js';

export default function Dashboard({ clients, projects, tasks, invoices, goView, openCreate, toggleTask }) {
  const hour = new Date().getHours();
  const greet = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
  const dateStr = new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });

  const paid30 = invoices.filter(i => i.status === 'paid' && daysUntil(i.issued) >= -30).reduce((s, i) => s + invTotal(i), 0);
  const active = projects.filter(p => p.status !== 'completed');
  const dueWeek = active.filter(p => daysUntil(p.deadline) <= 7).length;
  const openInv = invoices.filter(i => i.status !== 'paid');
  const overdueN = invoices.filter(i => i.status === 'overdue').length;
  const dueToday = tasks.filter(t => t.status !== 'done' && daysUntil(t.due) <= 0);
  const doing = tasks.filter(t => t.status === 'doing').length;
  const focus = dueToday.slice().sort((a, b) => (a.prio === 'high' ? -1 : 1) - (b.prio === 'high' ? -1 : 1));
  const deadlines = active.slice().sort((a, b) => daysUntil(a.deadline) - daysUntil(b.deadline)).slice(0, 5);
  const cName = id => { const c = clients.find(x => x.id === id); return c ? (c.company || c.name) : 'Former client'; };

  return (
    <React.Fragment>
      <div className="view-head">
        <div>
          <span className="eyebrow"><Icon name="calendar" size={13} />{dateStr}</span>
          <h1 className="dash-h">{greet}, <em>Sara.</em></h1>
          <p className="view-sub">
            {dueToday.length > 0
              ? 'You have ' + dueToday.length + ' task' + (dueToday.length > 1 ? 's' : '') + ' due today'
              : 'Nothing is due today — enjoy the calm'}
            {openInv.length > 0 ? ' and ' + openInv.length + ' invoice' + (openInv.length > 1 ? 's' : '') + ' awaiting payment.' : '.'}
          </p>
        </div>
        <div className="view-actions">
          <button className="btn btn-ghost" onClick={() => openCreate('task')}><Icon name="plus" size={15} />New task</button>
          <button className="btn btn-primary" onClick={() => openCreate('invoice')}><Icon name="file" size={15} />New invoice</button>
        </div>
      </div>

      <div className="stat-strip panel">
        <div className="stat">
          <span className="stat-k"><span className="sk-ico"><Icon name="banknote" size={15} /></span>Earnings · last 30 days</span>
          <div className="stat-v"><CountUp value={paid30} moneyFormat /></div>
          <span className="stat-d"><b>+18%</b> vs. the previous month</span>
        </div>
        <div className="stat click" onClick={() => goView('projects')}>
          <span className="stat-k"><span className="sk-ico"><Icon name="folder" size={15} /></span>Active projects</span>
          <div className="stat-v"><CountUp value={active.length} /></div>
          <span className="stat-d">{dueWeek} due this week</span>
        </div>
        <div className="stat click" onClick={() => goView('invoices')}>
          <span className="stat-k"><span className="sk-ico"><Icon name="file" size={15} /></span>Outstanding invoices</span>
          <div className="stat-v"><CountUp value={openInv.reduce((s, i) => s + invTotal(i), 0)} moneyFormat /></div>
          <span className="stat-d">
            {openInv.length} open{overdueN > 0 && <span className="warn"> · {overdueN} overdue</span>}
          </span>
        </div>
        <div className="stat click" onClick={() => goView('tasks')}>
          <span className="stat-k"><span className="sk-ico"><Icon name="tasks" size={15} /></span>Tasks due today</span>
          <div className="stat-v"><CountUp value={dueToday.length} /></div>
          <span className="stat-d">{doing} in progress right now</span>
        </div>
      </div>

      <div className="dash-grid">
        <div className="dash-col">
          <EarningsChart />
          <div className="panel">
            <div className="panel-head">
              <div>
                <h3 className="panel-title">Active projects</h3>
                <p className="panel-sub">Sorted by what needs you first</p>
              </div>
              <button className="link" onClick={() => goView('projects')}>View all</button>
            </div>
            {active.slice().sort((a, b) => daysUntil(a.deadline) - daysUntil(b.deadline)).slice(0, 4).map(p => {
              const ts = tasks.filter(t => t.projectId === p.id);
              const pct = ts.length ? Math.round(ts.filter(t => t.status === 'done').length / ts.length * 100) : (p.progress || 0);
              return (
                <div className="dproj" key={p.id} onClick={() => goView('projects')}>
                  <div>
                    <b>{p.title}</b>
                    <div className="dp-c">{cName(p.clientId)}</div>
                  </div>
                  <div>
                    <div className="bar-row"><div className="bar"><i style={{ width: pct + '%' }} /></div><span className="bar-pct">{pct}%</span></div>
                    {ts.length > 0 && <div className="bar-cap">{ts.filter(t => t.status === 'done').length} of {ts.length} tasks done</div>}
                  </div>
                  <DueChip date={p.deadline} />
                </div>
              );
            })}
          </div>
        </div>

        <div className="dash-col">
          <div className="panel">
            <div className="panel-head">
              <div>
                <h3 className="panel-title">Today’s focus</h3>
                <p className="panel-sub">Overdue and due today</p>
              </div>
              <button className="link" onClick={() => openCreate('task')}>Add</button>
            </div>
            {focus.length === 0 && (
              <div className="empty-mini">
                <span className="em-ico"><Icon name="sprout" size={20} /></span>
                All clear for today. Everything is where it should be.
              </div>
            )}
            {focus.map(t => (
              <div className="focus-item" key={t.id}>
                <span className="ck" onClick={() => toggleTask(t.id)}><Icon name="check" size={13} /></span>
                <div className="focus-body">
                  <p>{t.title}</p>
                  <div className="tmeta">
                    {t.projectId && <span className="tproj">{(projects.find(p => p.id === t.projectId) || {}).title || ''}</span>}
                    <span className={'chip-sm' + (daysUntil(t.due) < 0 ? ' over' : '')}>{dueText(t.due)}</span>
                    <span className="tprio"><i style={{ background: PRIO[t.prio].color }} />{PRIO[t.prio].label}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="panel">
            <div className="panel-head">
              <div>
                <h3 className="panel-title">Upcoming deadlines</h3>
                <p className="panel-sub">Project milestones ahead</p>
              </div>
            </div>
            {deadlines.map(p => {
              const d = new Date(p.deadline + 'T00:00:00');
              const over = daysUntil(p.deadline) < 0;
              return (
                <div className="dl-item" key={p.id} onClick={() => goView('projects')}>
                  <span className={'dl-date' + (over ? ' over' : '')}>
                    <b>{d.getDate()}</b><span>{d.toLocaleDateString('en-US', { month: 'short' })}</span>
                  </span>
                  <div className="dl-body">
                    <b>{p.title}</b>
                    <span>{cName(p.clientId)} · {dlText(p.deadline)}</span>
                  </div>
                  <span className="go"><Icon name="chevr" size={16} /></span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </React.Fragment>
  );
}
