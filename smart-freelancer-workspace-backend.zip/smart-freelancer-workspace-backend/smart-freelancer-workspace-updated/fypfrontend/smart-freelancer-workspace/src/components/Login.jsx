import React, { useState } from 'react';
import { Icon, Logo } from '../Icons.jsx';
import { avStyle } from '../utils.js';

export default function Login({ onLogin, notify }) {
  const [email, setEmail] = useState('');
  const [pwd, setPwd] = useState('');
  const [show, setShow] = useState(false);
  const [remember, setRemember] = useState(true);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = e => {
    e.preventDefault();
    if (!email.includes('@') || !email.trim()) return setErr('Please enter a valid email address.');
    if (pwd.length < 4) return setErr('Password must be at least 4 characters.');
    setErr('');
    setBusy(true);
    setTimeout(() => onLogin(email), 900);
  };

  return (
    <div className="login">
      <div className="login-brand">
        <div className="deco">
          <span className="d-ring" /><span className="d-ring2" />
          <span className="d-leaf l1" /><span className="d-leaf l2" /><span className="d-dot" />
        </div>
        <div className="lb-top">
          <Logo size={40} />
          <div className="lb-lockup"><b>Smart Freelancer</b><i>Workspace</i></div>
        </div>
        <div className="lb-mid">
          <h1>Every client, project and invoice in <em>one calm place.</em></h1>
          <p className="lb-sub">Stop juggling chat apps, notes and spreadsheets. Run your entire freelance business from a single dashboard.</p>
          <ul className="lb-feats">
            <li><span className="lb-ico"><Icon name="users" size={17} /></span><div><b>Client directory</b><span>Contacts, companies and history — organised.</span></div></li>
            <li><span className="lb-ico"><Icon name="folder" size={17} /></span><div><b>Projects &amp; tasks</b><span>Deadlines, progress and kanban status at a glance.</span></div></li>
            <li><span className="lb-ico"><Icon name="file" size={17} /></span><div><b>Invoices</b><span>Create, send and track every payment.</span></div></li>
          </ul>
        </div>
        <div className="lb-quote">
          <p>“I replaced four separate tools with this one dashboard — my week finally feels under control.”</p>
          <div>
            <span className="avatar" style={avStyle('Sara Malik')}>SM</span>
            <div><b>Sara Malik</b><i>Freelance Product Designer</i></div>
          </div>
        </div>
      </div>
      <div className="login-form-wrap">
        <form className="login-form" onSubmit={submit}>
          <h2>Welcome back</h2>
          <p>Sign in to your workspace to continue.</p>
          {err && <div className="form-err"><Icon name="alert" size={15} />{err}</div>}
          <div className="field">
            <label>Email</label>
            <input className="input" type="text" placeholder="you@studio.com" value={email}
              onChange={e => setEmail(e.target.value)} autoFocus />
          </div>
          <div className="field">
            <label>Password</label>
            <div className="pwd-wrap">
              <input className="input" type={show ? 'text' : 'password'} placeholder="••••••••" value={pwd}
                onChange={e => setPwd(e.target.value)} />
              <button type="button" className="pwd-eye" onClick={() => setShow(!show)}>
                <Icon name={show ? 'eyeoff' : 'eye'} size={16} />
              </button>
            </div>
          </div>
          <div className="form-row">
            <span className="ck-row" onClick={() => setRemember(!remember)}>
              <span className={'ck' + (remember ? ' on' : '')}><Icon name="check" size={13} /></span>Remember me
            </span>
            <button type="button" className="link" onClick={() => notify('Demo mode — any credentials will sign you in.', 'info')}>Forgot password?</button>
          </div>
          <button className="btn btn-primary btn-lg" disabled={busy}>
            {busy ? <span className="spin" /> : <>Sign in <Icon name="arrowright" size={16} /></>}
          </button>
          <div className="demo-hint">
            <span>This is a frontend demo — any email and a 4+ character password works.</span>
            <button type="button" className="link"
              onClick={() => { setEmail('sara@freelance.dev'); setPwd('workspace'); }}>Fill demo credentials</button>
          </div>
        </form>
        <p className="login-foot">React · Spring Boot · MySQL — Final Year Project prototype</p>
      </div>
    </div>
  );
}
