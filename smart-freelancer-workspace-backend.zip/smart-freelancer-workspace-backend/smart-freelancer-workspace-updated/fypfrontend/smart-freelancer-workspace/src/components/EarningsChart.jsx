import React, { useState } from 'react';
import { MONTHS, EARN } from '../data.js';
import { money } from '../utils.js';

export default function EarningsChart() {
  const [range, setRange] = useState(12);
  const [hover, setHover] = useState(null);
  const data = EARN.slice(-range), labels = MONTHS.slice(-range);
  const W = 640, H = 240, P = { t: 14, r: 10, b: 26, l: 46 };
  const max = Math.ceil(Math.max(...data) / 1000) * 1000;
  const xs = i => P.l + i * (W - P.l - P.r) / (data.length - 1);
  const ys = v => H - P.b - (v / max) * (H - P.t - P.b);
  const line = data.map((v, i) => (i ? 'L' : 'M') + xs(i) + ',' + ys(v)).join('');
  const area = line + ' L' + xs(data.length - 1) + ',' + (H - P.b) + ' L' + xs(0) + ',' + (H - P.b) + ' Z';
  const fmt = v => v >= 1000 ? '$' + (v / 1000).toFixed(1).replace(/\.0$/, '') + 'k' : '$' + v;

  const onMove = e => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width * W;
    let i = Math.round((x - P.l) / ((W - P.l - P.r) / (data.length - 1)));
    setHover(Math.max(0, Math.min(data.length - 1, i)));
  };

  return (
    <div className="panel">
      <div className="panel-head">
        <div>
          <h3 className="panel-title">Earnings</h3>
          <p className="panel-sub">Paid invoices, month by month</p>
        </div>
        <div className="seg">
          {[6, 12].map(r => (
            <button key={r} className={'seg-btn' + (range === r ? ' on' : '')}
              onClick={() => { setRange(r); setHover(null); }}>{r}M</button>
          ))}
        </div>
      </div>
      <div className="chart-wrap" onMouseLeave={() => setHover(null)}>
        <svg viewBox={'0 0 ' + W + ' ' + H} onMouseMove={onMove} key={range}>
          {[0, 0.5, 1].map(f => {
            const y = ys(max * f);
            return (
              <g key={f}>
                <line x1={P.l} x2={W - P.r} y1={y} y2={y} stroke="#E7EEE3" strokeWidth="1" />
                {f > 0 && <text x={P.l - 8} y={y + 3.5} textAnchor="end" className="ax">{fmt(max * f)}</text>}
              </g>
            );
          })}
          <path d={area} className="chart-area" />
          <path d={line} className="chart-line" />
          {data.map((v, i) => <text key={i} x={xs(i)} y={H - 8} textAnchor="middle" className="ax">{labels[i]}</text>)}
          {hover != null && (
            <g>
              <line x1={xs(hover)} x2={xs(hover)} y1={P.t} y2={H - P.b} stroke="#0E7A47" strokeWidth="1" strokeDasharray="3 3" opacity=".5" />
              <circle cx={xs(hover)} cy={ys(data[hover])} r="5" fill="#0E7A47" stroke="#fff" strokeWidth="2.5" />
            </g>
          )}
        </svg>
        {hover != null && (
          <div className="chart-tip" style={{ left: (xs(hover) / W * 100) + '%', top: (ys(data[hover]) / H * 100) + '%' }}>
            <b>{money(data[hover])}</b><span>{labels[hover]}</span>
          </div>
        )}
      </div>
    </div>
  );
}
