import React, { useState, useRef, useEffect } from 'react';
import { Icon } from '../Icons.jsx';
import { useOutside } from './shared.jsx';

function GlobalSearch({ clients, projects, invoices, onGo }) {
  const [q, setQ] = useState('');
  const [open, setOpen] = useState(false);
  const ref = useRef(null), inputRef = useRef(null);
  useOutside(ref, () => setOpen(false));

  useEffect(() => {
    const h = e => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        if (inputRef.current) inputRef.current.focus();
        setOpen(true);
      }
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, []);

  const lq = q.trim().toLowerCase();
  const groups = lq ? [
    { label: 'Clients', icon: 'users', items: clients.filter(c => (c.name + ' ' + c.company + ' ' + c.email).toLowerCase().includes(lq)).map(c => ({ id: c.id, name: c.name, sub: c.company })) },
    { label: 'Projects', icon: 'folder', items: projects.filter(p => p.title.toLowerCase().includes(lq)).map(p => ({ id: p.id, name: p.title, sub: 'Project' })) },
    { label: 'Invoices', icon: 'file', items: invoices.filter(i => (i.number).toLowerCase().includes(lq)).map(i => ({ id: i.id, name: i.number, sub: 'Invoice' })) },
  ] : [];
  const total = groups.reduce((s, g) => s + g.items.length, 0);

  return (
    <div className="searchbox" ref={ref}>
      <Icon name="search" size={16} />
      <input ref={inputRef} placeholder="Search clients, projects, invoices…"
        value={q}
        onChange={e => { setQ(e.target.value); setOpen(true); }}
        onKeyDown={e => { if (e.key === 'Escape') { setQ(''); setOpen(false); if (inputRef.current) inputRef.current.blur(); } }} />
      <span className="kbd">⌘K</span>
      {open && lq && (
        <div className="pop pop-left" style={{ width: 'min(380px,90vw)' }}>
          {groups.map(g => g.items.length > 0 && (
            <div key={g.label}>
              <div className="pop-label">{g.label}</div>
              {g.items.map(it => (
                <button key={it.id} className="pop-item" onClick={() => { onGo(g.label, it.id); setQ(''); setOpen(false); }}>
                  <span className="pi"><Icon name={g.icon} size={15} /></span>
                  <span style={{ minWidth: 0 }}>
                    <b style={{ display: 'block', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{it.name}</b>
                    <small>{it.sub}</small>
                  </span>
                </button>
              ))}
            </div>
          ))}
          {total === 0 && <div className="pop-empty">No matches for “{q}”</div>}
        </div>
      )}
    </div>
  );
}

export default function Topbar({ clients, projects, invoices, notifs, onGo, startCreate, markAllRead }) {
  const [newOpen, setNewOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const newRef = useRef(null), notifRef = useRef(null);
  useOutside(newRef, () => setNewOpen(false));
  useOutside(notifRef, () => setNotifOpen(false));
  const unread = notifs.filter(n => !n.read).length;

  return (
    <header className="topbar">
      <GlobalSearch clients={clients} projects={projects} invoices={invoices} onGo={onGo} />
      <div className="topbar-right">
        <div ref={newRef} style={{ position: 'relative' }}>
          <button className="btn btn-primary" onClick={() => setNewOpen(!newOpen)}>
            <Icon name="plus" size={15} />New<Icon name="chevd" size={13} />
          </button>
          {newOpen && (
            <div className="pop pop-right">
              <div className="pop-label">Create</div>
              {[['client', 'Client', 'Add someone new', 'users'], ['project', 'Project', 'Track new work', 'folder'],
              ['task', 'Task', 'Add to the board', 'tasks'], ['invoice', 'Invoice', 'Bill a client', 'file']].map(([k, t, s, ic]) => (
                <button key={k} className="pop-item" onClick={() => { setNewOpen(false); startCreate(k); }}>
                  <span className="pi"><Icon name={ic} size={15} /></span>
                  <span><b>{t}</b><small>{s}</small></span>
                </button>
              ))}
            </div>
          )}
        </div>
        <div ref={notifRef} style={{ position: 'relative' }}>
          <button className="tbell" onClick={() => setNotifOpen(!notifOpen)}>
            <Icon name="bell" size={18} />
            {unread > 0 && <span className="tbadge">{unread}</span>}
          </button>
          {notifOpen && (
            <div className="pop pop-right notif-pop">
              <div className="notif-head">
                <b>Notifications</b>
                {unread > 0 && <button className="link" onClick={markAllRead}>Mark all as read</button>}
              </div>
              <div className="notif-list">
                {notifs.map(n => (
                  <div key={n.id} className={'notif' + (n.read ? '' : ' unread')}>
                    <span className="ni"><Icon name={n.icon} size={16} /></span>
                    <div><p>{n.text}</p><time>{n.time}</time></div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
        <span className="avatar-top">SM</span>
      </div>
    </header>
  );
}
