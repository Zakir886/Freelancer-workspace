import React, { useState } from 'react';
import { Icon } from '../Icons.jsx';
import { Modal, Pill, DueChip, EmptyState } from './shared.jsx';
import { daysUntil, money, addDays } from '../utils.js';
import { PSTAT } from '../data.js';

export function ProjectsView({ clients, projects, tasks, onAdd, onEdit, onDelete, goProjectTasks, query, setQuery }) {
  const [tab, setTab] = useState('all');
  const q = query;
  const counts = {
    all: projects.length,
    in_progress: projects.filter(p => p.status === 'in_progress').length,
    on_hold: projects.filter(p => p.status === 'on_hold').length,
    completed: projects.filter(p => p.status === 'completed').length,
  };
  const cName = id => { const c = clients.find(x => x.id === id); return c ? (c.company || c.name) : 'Former client'; };
  const rows = projects
    .filter(p => tab === 'all' || p.status === tab)
    .filter(p => p.title.toLowerCase().includes(q.toLowerCase()) || cName(p.clientId).toLowerCase().includes(q.toLowerCase()))
    .sort((a, b) => daysUntil(a.deadline) - daysUntil(b.deadline));

  return (
    <React.Fragment>
      <div className="view-head">
        <div>
          <h2 className="view-title">Projects</h2>
          <p className="view-sub">{counts.in_progress} in progress · {counts.completed} completed</p>
        </div>
        <div className="view-actions">
          <div className="vsearch"><Icon name="search" size={15} />
            <input placeholder="Search projects…" value={q} onChange={e => setQuery(e.target.value)} />
          </div>
          <button className="btn btn-primary" onClick={onAdd}><Icon name="plus" size={15} />New project</button>
        </div>
      </div>
      <div className="tabs">
        {[['all', 'All'], ['in_progress', 'In progress'], ['on_hold', 'On hold'], ['completed', 'Completed']].map(([k, l]) => (
          <button key={k} className={'tab' + (tab === k ? ' on' : '')} onClick={() => setTab(k)}>
            {l}<span className="n">{counts[k]}</span>
          </button>
        ))}
      </div>
      <div className="panel">
        {rows.length === 0 ? <EmptyState q={q || tab} onClear={() => { setQuery(''); setTab('all'); }} /> : (
          <div className="table-wrap"><table className="table">
            <thead><tr><th>Project</th><th>Progress</th><th>Deadline</th><th>Budget</th><th>Status</th><th></th></tr></thead>
            <tbody>
              {rows.map(p => {
                const ts = tasks.filter(t => t.projectId === p.id);
                const pct = ts.length ? Math.round(ts.filter(t => t.status === 'done').length / ts.length * 100) : (p.progress || 0);
                return (
                  <tr key={p.id} onClick={() => onEdit(p)}>
                    <td><div className="td-main"><b>{p.title}</b><span className="td-sub">{cName(p.clientId)}</span></div></td>
                    <td>
                      <div className="bar-row" style={{ minWidth: 150 }}>
                        <div className="bar"><i style={{ width: pct + '%' }} /></div>
                        <span className="bar-pct">{pct}%</span>
                      </div>
                      {ts.length > 0 && <span className="td-sub num">{ts.filter(t => t.status === 'done').length}/{ts.length} tasks</span>}
                    </td>
                    <td><DueChip date={p.deadline} /></td>
                    <td className="num"><b>{money(p.budget)}</b></td>
                    <td><Pill cfg={PSTAT[p.status]} /></td>
                    <td>
                      <div className="row-acts">
                        <button className="mini-btn" title="View tasks" onClick={e => { e.stopPropagation(); goProjectTasks(p); }}><Icon name="tasks" size={14} /></button>
                        <button className="mini-btn" title="Edit" onClick={e => { e.stopPropagation(); onEdit(p); }}><Icon name="pencil" size={14} /></button>
                        <button className="mini-btn del" title="Delete" onClick={e => { e.stopPropagation(); onDelete(p); }}><Icon name="trash" size={14} /></button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table></div>
        )}
      </div>
    </React.Fragment>
  );
}

export function ProjectModal({ init, clients, onClose, onSave }) {
  const [f, setF] = useState(init
    ? { title: init.title, clientId: init.clientId, status: init.status, budget: init.budget, deadline: init.deadline }
    : { title: '', clientId: '', status: 'in_progress', budget: '', deadline: addDays(21) });
  const [err, setErr] = useState('');
  const set = k => e => setF({ ...f, [k]: e.target.value });

  const save = () => {
    if (!f.title.trim()) return setErr('Give the project a title.');
    if (!f.clientId) return setErr('Choose the client this project belongs to.');
    onSave({ ...f, budget: Number(f.budget) || 0, id: init ? init.id : null, progress: init ? init.progress : 0 });
  };

  return (
    <Modal onClose={onClose} width={560}>
      <div className="mod-head">
        <h3 className="mod-title">{init ? 'Edit project' : 'New project'}</h3>
        <button className="mod-x" onClick={onClose}><Icon name="x" size={17} /></button>
      </div>
      <div className="mod-body">
        {err && <div className="form-err"><Icon name="alert" size={15} />{err}</div>}
        <div className="field"><label>Project title *</label>
          <input className="input" placeholder="e.g. Analytics dashboard UI" value={f.title} onChange={set('title')} autoFocus /></div>
        <div className="frow">
          <div className="field"><label>Client *</label>
            <select className="input" value={f.clientId} onChange={set('clientId')}>
              <option value="">Select a client…</option>
              {clients.map(c => <option key={c.id} value={c.id}>{c.name} — {c.company}</option>)}
            </select></div>
          <div className="field"><label>Status</label>
            <select className="input" value={f.status} onChange={set('status')}>
              <option value="in_progress">In progress</option>
              <option value="on_hold">On hold</option>
              <option value="completed">Completed</option>
            </select></div>
        </div>
        <div className="frow">
          <div className="field"><label>Budget ($)</label>
            <input className="input num" type="number" min="0" placeholder="2500" value={f.budget} onChange={set('budget')} /></div>
          <div className="field"><label>Deadline</label>
            <input className="input" type="date" value={f.deadline} onChange={set('deadline')} /></div>
        </div>
      </div>
      <div className="mod-foot">
        <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
        <button className="btn btn-primary" onClick={save}>{init ? 'Save changes' : 'Create project'}</button>
      </div>
    </Modal>
  );
}
