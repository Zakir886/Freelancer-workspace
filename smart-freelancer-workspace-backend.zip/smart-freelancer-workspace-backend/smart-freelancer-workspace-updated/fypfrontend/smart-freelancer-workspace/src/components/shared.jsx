import React, { useState, useEffect, useRef } from 'react';
import { Icon } from '../Icons.jsx';
import { daysUntil, fmtDate, money } from '../utils.js';

export function CountUp({ value, moneyFormat, dur = 900 }) {
  const [v, setV] = useState(0);
  const fromRef = useRef(0);
  useEffect(() => {
    const from = fromRef.current, t0 = performance.now();
    let raf;
    const step = t => {
      const p = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - p, 3);
      setV(from + (value - from) * e);
      if (p < 1) raf = requestAnimationFrame(step);
      else fromRef.current = value;
    };
    raf = requestAnimationFrame(step);
    return () => { cancelAnimationFrame(raf); fromRef.current = value; };
  }, [value]);
  return <>{moneyFormat ? money(v) : Math.round(v)}</>;
}

export function Modal({ children, onClose, width = 520 }) {
  return (
    <div className="ovl" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal" style={{ maxWidth: width }} onMouseDown={e => e.stopPropagation()}>
        {children}
      </div>
    </div>
  );
}

export function Pill({ cfg }) {
  return <span className={'pill ' + cfg.cls}><i></i>{cfg.label}</span>;
}

export function DueChip({ date }) {
  const d = daysUntil(date);
  let cls = 'due', txt = fmtDate(date);
  if (d < 0) { cls += ' over'; txt = (-d) + 'd overdue'; }
  else if (d === 0) { cls += ' soon'; txt = 'Due today'; }
  else if (d <= 3) { cls += ' soon'; txt = d === 1 ? 'Due tomorrow' : 'Due in ' + d + 'd'; }
  return <span className={cls}>{txt}</span>;
}

export function EmptyState({ q, onClear }) {
  return (
    <div className="empty">
      <span className="eico"><Icon name="search" size={22} /></span>
      <b>No matches</b>
      <p>Nothing found for “{q}”.</p>
      <button className="btn btn-ghost" onClick={onClear}>Clear search</button>
    </div>
  );
}

export function useOutside(ref, cb) {
  useEffect(() => {
    const h = e => { if (ref.current && !ref.current.contains(e.target)) cb(); };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, [ref]);
}

export function Toasts({ items, dismiss }) {
  return (
    <div className="toasts">
      {items.map(t => (
        <div key={t.id} className={'toast' + (t.leaving ? ' out' : '')}>
          <span className="t-ico"><Icon name={t.type === 'error' ? 'alert' : 'check'} size={16} /></span>
          <span>{t.msg}</span>
          <button className="t-x" onClick={() => dismiss(t.id)}><Icon name="x" size={13} /></button>
        </div>
      ))}
    </div>
  );
}
