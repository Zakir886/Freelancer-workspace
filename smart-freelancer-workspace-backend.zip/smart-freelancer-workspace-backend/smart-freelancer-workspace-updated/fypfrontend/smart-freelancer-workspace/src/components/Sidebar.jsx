import React from 'react';
import { Icon, Logo } from '../Icons.jsx';
import { avStyle } from '../utils.js';

export default function Sidebar({ view, setView, counts, onLogout }) {
  const items = [
    { id: 'dashboard', label: 'Dashboard', icon: 'dashboard' },
    { id: 'clients', label: 'Clients', icon: 'users', n: counts.clients },
    { id: 'projects', label: 'Projects', icon: 'folder', n: counts.projects },
    { id: 'tasks', label: 'Tasks', icon: 'tasks', n: counts.tasks },
    { id: 'invoices', label: 'Invoices', icon: 'file', n: counts.invoices },
  ];
  return (
    <aside className="sidebar">
      <div className="sb-brand" onClick={() => setView('dashboard')}>
        <Logo size={36} />
        <div className="sb-lockup"><b>Smart Freelancer</b><i>Workspace</i></div>
      </div>
      <div className="sb-label">Menu</div>
      <nav className="sb-nav">
        {items.map(it => (
          <div key={it.id} className={'nav-item' + (view === it.id ? ' on' : '')} onClick={() => setView(it.id)}>
            <Icon name={it.icon} size={18} />
            <span className="sb-txt">{it.label}</span>
            {it.n != null && <span className="sb-badge">{it.n}</span>}
          </div>
        ))}
      </nav>
      <div className="sb-foot">
        <div className="sb-user">
          <span className="avatar" style={avStyle('Sara Malik')}>SM</span>
          <div className="sb-user-info"><b>Sara Malik</b><i>Product Designer</i></div>
        </div>
        <button className="sb-logout" title="Sign out" onClick={onLogout}><Icon name="logout" size={17} /></button>
      </div>
    </aside>
  );
}
