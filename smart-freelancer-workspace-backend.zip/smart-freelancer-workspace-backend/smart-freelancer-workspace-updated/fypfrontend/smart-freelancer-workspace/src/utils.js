const _TODAY = new Date();
_TODAY.setHours(0, 0, 0, 0);
export const TODAY = _TODAY;

export const iso = d => {
  const x = new Date(d);
  x.setHours(12, 0, 0, 0);
  return x.toISOString().slice(0, 10);
};

export const addDays = n => iso(new Date(TODAY.getTime() + n * 864e5));

export const daysUntil = s => Math.round((new Date(s + 'T00:00:00') - TODAY) / 864e5);

export const fmtDate = s =>
  new Date(s + 'T00:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

export const fmtDateLong = s =>
  new Date(s + 'T00:00:00').toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });

export const money = n => '$' + Math.round(n).toLocaleString('en-US');

export const invTotal = inv =>
  inv.items.reduce((s, it) => s + (Number(it.q) || 0) * (Number(it.r) || 0), 0);

let _uid = 100;
export const uid = () => 'x' + (_uid++);

export const dueText = s => {
  const d = daysUntil(s);
  if (d < 0) return (-d) + 'd late';
  if (d === 0) return 'Today';
  if (d === 1) return 'Tomorrow';
  return fmtDate(s);
};

export const dlText = s => {
  const d = daysUntil(s);
  if (d < 0) return (-d) + 'd overdue';
  if (d === 0) return 'Due today';
  if (d === 1) return 'Due tomorrow';
  return 'Due in ' + d + 'd';
};

const AV = [
  { backgroundColor: '#DFF2E4', color: '#0B5C35' },
  { backgroundColor: '#F3EDDA', color: '#6E5A1E' },
  { backgroundColor: '#CDE8D4', color: '#0A4A2C' },
  { backgroundColor: '#D9EFE7', color: '#0B5348' },
  { backgroundColor: '#E4EDDA', color: '#3F5A28' },
];

export const initials = n =>
  n.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();

export const avStyle = n => {
  let h = 0;
  for (const c of n) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  return AV[h % AV.length];
};
