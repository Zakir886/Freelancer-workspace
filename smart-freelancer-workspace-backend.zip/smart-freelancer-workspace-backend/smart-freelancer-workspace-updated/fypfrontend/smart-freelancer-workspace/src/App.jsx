import React, { useState, useEffect } from 'react';
import { Icon } from './Icons.jsx';
import Login from './components/Login.jsx';
import Sidebar from './components/Sidebar.jsx';
import Topbar from './components/Topbar.jsx';
import Dashboard from './components/Dashboard.jsx';
import { ClientsView, ClientModal, ClientDrawer } from './components/Clients.jsx';
import { ProjectsView, ProjectModal } from './components/Projects.jsx';
import { TasksView, TaskModal } from './components/Tasks.jsx';
import { InvoicesView, InvoiceModal, InvoicePreview } from './components/Invoices.jsx';
import { Modal, Toasts } from './components/shared.jsx';
import { SEED_CLIENTS, SEED_PROJECTS, SEED_TASKS, SEED_INVOICES, SEED_NOTIFS } from './data.js';
import { uid, invTotal, money } from './utils.js';

export default function App() {
  const [authed, setAuthed] = useState(false);
  const [view, setView] = useState('dashboard');
  const [clients, setClients] = useState(SEED_CLIENTS);
  const [projects, setProjects] = useState(SEED_PROJECTS);
  const [tasks, setTasks] = useState(SEED_TASKS);
  const [invoices, setInvoices] = useState(SEED_INVOICES);
  const [notifs, setNotifs] = useState(SEED_NOTIFS);
  const [toasts, setToasts] = useState([]);
  const [drawer, setDrawer] = useState(null);
  const [clientModal, setClientModal] = useState(null);
  const [projectModal, setProjectModal] = useState(null);
  const [taskModal, setTaskModal] = useState(null);
  const [invoiceModal, setInvoiceModal] = useState(false);
  const [invoiceView, setInvoiceView] = useState(null);
  const [confirmBox, setConfirmBox] = useState(null);
  const [taskProject, setTaskProject] = useState('all');
  const [projectQuery, setProjectQuery] = useState('');
  const [flashId, setFlashId] = useState(null);

  const toast = (msg, type = 'success') => {
    const id = uid();
    setToasts(t => [...t, { id, msg, type }]);
    setTimeout(() => dismissToast(id), 3400);
  };
  const dismissToast = id => {
    setToasts(t => t.map(x => x.id === id ? { ...x, leaving: true } : x));
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 240);
  };

  useEffect(() => {
    const h = e => {
      if (e.key === 'Escape') {
        setDrawer(null); setClientModal(null); setProjectModal(null);
        setTaskModal(null); setInvoiceModal(false); setInvoiceView(null); setConfirmBox(null);
      }
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, []);

  const saveClient = data => {
    if (data.id) { setClients(cs => cs.map(c => c.id === data.id ? data : c)); toast('Client details updated.'); }
    else { setClients(cs => [{ ...data, id: uid() }, ...cs]); toast('Client added to your directory.'); }
    setClientModal(null);
  };
  const askDeleteClient = c => setConfirmBox({
    title: 'Delete ' + c.name + '?',
    message: 'Their projects and invoices will remain in your records, shown as “Former client”.',
    confirm: 'Delete client',
    action: () => { setClients(cs => cs.filter(x => x.id !== c.id)); setDrawer(null); setConfirmBox(null); toast('Client removed.', 'info'); }
  });
  const saveProject = data => {
    if (data.id) { setProjects(ps => ps.map(p => p.id === data.id ? data : p)); toast('Project updated.'); }
    else { setProjects(ps => [{ ...data, id: uid() }, ...ps]); toast('Project created — good luck with it!'); }
    setProjectModal(null);
  };
  const askDeleteProject = p => {
    const n = tasks.filter(t => t.projectId === p.id).length;
    setConfirmBox({
      title: 'Delete “' + p.title + '”?',
      message: n ? 'This will also remove its ' + n + ' task' + (n === 1 ? '' : 's') + ' from your board.' : 'This project will be removed from your workspace.',
      confirm: 'Delete project',
      action: () => { setProjects(ps => ps.filter(x => x.id !== p.id)); setTasks(ts => ts.filter(t => t.projectId !== p.id)); setProjectModal(null); setConfirmBox(null); toast('Project deleted.', 'info'); }
    });
  };
  const saveTask = data => {
    if (data.id) { setTasks(ts => ts.map(t => t.id === data.id ? data : t)); toast('Task updated.'); }
    else { const id = uid(); setTasks(ts => [...ts, { ...data, id }]); setFlashId(id); setTimeout(() => setFlashId(null), 700); toast('Task added to your board.'); }
    setTaskModal(null);
  };
  const askDeleteTask = t => setConfirmBox({
    title: 'Delete this task?',
    message: '“' + t.title + '” will be removed from your board.',
    confirm: 'Delete task',
    action: () => { setTasks(ts => ts.filter(x => x.id !== t.id)); setTaskModal(null); setConfirmBox(null); toast('Task removed.', 'info'); }
  });
  const moveTask = (id, status) => {
    let task = null;
    setTasks(ts => ts.map(t => { if (t.id === id) { task = { ...t, status }; return { ...t, status }; } return t; }));
    if (task) {
      setFlashId(id); setTimeout(() => setFlashId(null), 700);
      if (status === 'done') toast('Task completed — nice work!');
      else if (task.status === 'done' && status !== 'done') toast('Task reopened.', 'info');
      else toast('Moved to ' + (status === 'doing' ? 'In Progress' : 'To Do') + '.', 'info');
    }
  };
  const toggleTask = id => {
    const t = tasks.find(x => x.id === id);
    if (t) moveTask(id, t.status === 'done' ? 'todo' : 'done');
  };
  const nextInvNumber = 'INV-2026-' + String(
    invoices.reduce((m, i) => Math.max(m, parseInt(i.number.slice(-3), 10)), 0) + 1
  ).padStart(3, '0');
  const createInvoice = data => {
    setInvoices(is => [{ ...data, id: uid(), number: nextInvNumber }, ...is]);
    setInvoiceModal(false);
    toast('Invoice ' + nextInvNumber + ' created — ' + money(invTotal(data)) + ' outstanding.');
  };
  const markPaid = id => {
    const inv = invoices.find(i => i.id === id);
    setInvoices(is => is.map(i => i.id === id ? { ...i, status: 'paid' } : i));
    if (inv) toast('Payment recorded — ' + inv.number + ' (' + money(invTotal(inv)) + ').');
  };
  const askDeleteInvoice = inv => setConfirmBox({
    title: 'Delete ' + inv.number + '?',
    message: 'This ' + money(invTotal(inv)) + ' invoice will be permanently removed.',
    confirm: 'Delete invoice',
    action: () => { setInvoices(is => is.filter(x => x.id !== inv.id)); setInvoiceView(null); setConfirmBox(null); toast('Invoice deleted.', 'info'); }
  });

  const startCreate = t => {
    if (t === 'client') { setView('clients'); setClientModal({ mode: 'new' }); }
    if (t === 'project') { setView('projects'); setProjectModal({ mode: 'new' }); }
    if (t === 'task') { setView('tasks'); setTaskModal({ mode: 'new', status: 'todo' }); }
    if (t === 'invoice') { setView('invoices'); setInvoiceModal(true); }
  };
  const goProjectTasks = p => { setTaskProject(p.id); setView('tasks'); setDrawer(null); toast('Showing tasks for “' + p.title + '”.', 'info'); };
  const searchGo = (group, id) => {
    if (group === 'Clients') { setView('clients'); setDrawer(id); }
    if (group === 'Projects') {
      const p = projects.find(x => x.id === id);
      setView('projects'); setProjectQuery(p ? p.title : '');
    }
    if (group === 'Invoices') { setView('invoices'); setInvoiceView(id); }
  };

  const drawerClient = clients.find(c => c.id === drawer);
  const previewInv = invoices.find(i => i.id === invoiceView);
  const counts = {
    clients: clients.length,
    projects: projects.filter(p => p.status !== 'completed').length,
    tasks: tasks.filter(t => t.status !== 'done').length,
    invoices: invoices.filter(i => i.status !== 'paid').length,
  };

  if (!authed) return (
    <React.Fragment>
      <Login onLogin={() => { setAuthed(true); toast('Welcome back, Sara — here’s your day at a glance.'); }} notify={toast} />
      <Toasts items={toasts} dismiss={dismissToast} />
    </React.Fragment>
  );

  return (
    <div className="app">
      <Sidebar view={view} setView={setView} counts={counts}
        onLogout={() => { setAuthed(false); toast('Signed out — see you soon.', 'info'); }} />
      <div className="app-body">
        <Topbar clients={clients} projects={projects} invoices={invoices} notifs={notifs}
          onGo={searchGo} startCreate={startCreate}
          markAllRead={() => setNotifs(ns => ns.map(n => ({ ...n, read: true })))} />
        <main className="main">
          <div className="view" key={view}>
            {view === 'dashboard' &&
              <Dashboard clients={clients} projects={projects} tasks={tasks} invoices={invoices}
                goView={setView} openCreate={startCreate} toggleTask={toggleTask} />}
            {view === 'clients' &&
              <ClientsView clients={clients} projects={projects} invoices={invoices}
                onAdd={() => setClientModal({ mode: 'new' })} onOpen={setDrawer} />}
            {view === 'projects' &&
              <ProjectsView clients={clients} projects={projects} tasks={tasks}
                onAdd={() => setProjectModal({ mode: 'new' })}
                onEdit={p => setProjectModal({ mode: 'edit', project: p })}
                onDelete={askDeleteProject}
                goProjectTasks={goProjectTasks}
                query={projectQuery} setQuery={setProjectQuery} />}
            {view === 'tasks' &&
              <TasksView projects={projects} tasks={tasks}
                taskProject={taskProject} setTaskProject={setTaskProject}
                onNew={st => setTaskModal({ mode: 'new', status: st })}
                onEdit={t => setTaskModal({ mode: 'edit', task: t })}
                onDelete={askDeleteTask}
                moveTask={moveTask} flashId={flashId} />}
            {view === 'invoices' &&
              <InvoicesView clients={clients} projects={projects} invoices={invoices}
                onAdd={() => setInvoiceModal(true)} onOpen={setInvoiceView}
                onMarkPaid={markPaid} onDelete={askDeleteInvoice} />}
          </div>
        </main>
      </div>

      {drawerClient && (
        <ClientDrawer client={drawerClient} projects={projects} invoices={invoices} tasks={tasks}
          onClose={() => setDrawer(null)}
          onEdit={() => setClientModal({ mode: 'edit', client: drawerClient })}
          onDelete={() => askDeleteClient(drawerClient)}
          goProjectTasks={goProjectTasks}
          openInvoice={id => { setDrawer(null); setInvoiceView(id); }} />
      )}
      {clientModal && (
        <ClientModal init={clientModal.client || null} onClose={() => setClientModal(null)} onSave={saveClient} />
      )}
      {projectModal && (
        <ProjectModal init={projectModal.project || null} clients={clients}
          onClose={() => setProjectModal(null)} onSave={saveProject} />
      )}
      {taskModal && (
        <TaskModal init={taskModal.task || null} status={taskModal.status} projects={projects}
          onClose={() => setTaskModal(null)} onSave={saveTask} />
      )}
      {invoiceModal && (
        <InvoiceModal clients={clients} projects={projects} nextNumber={nextInvNumber}
          onClose={() => setInvoiceModal(false)} onCreate={createInvoice} />
      )}
      {previewInv && (
        <InvoicePreview invoice={previewInv} client={clients.find(c => c.id === previewInv.clientId)} project={projects.find(p => p.id === previewInv.projectId)}
          onClose={() => setInvoiceView(null)} onMarkPaid={id => { markPaid(id); setInvoiceView(null); }} />
      )}
      {confirmBox && (
        <Modal onClose={() => setConfirmBox(null)} width={430}>
          <div className="cbox">
            <span className="cico"><Icon name="trash" size={22} /></span>
            <h3>{confirmBox.title}</h3>
            <p>{confirmBox.message}</p>
            <div className="cbtns">
              <button className="btn btn-ghost" onClick={() => setConfirmBox(null)}>Cancel</button>
              <button className="btn btn-danger" onClick={confirmBox.action}>{confirmBox.confirm}</button>
            </div>
          </div>
        </Modal>
      )}
      <Toasts items={toasts} dismiss={dismissToast} />
    </div>
  );
}
