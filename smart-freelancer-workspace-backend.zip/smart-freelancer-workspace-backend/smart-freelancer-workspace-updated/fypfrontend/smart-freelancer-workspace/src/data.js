import { addDays } from './utils.js';

export const PSTAT = {
  in_progress: { label: 'In progress', cls: 'st-green' },
  on_hold: { label: 'On hold', cls: 'st-amber' },
  completed: { label: 'Completed', cls: 'st-neutral' },
};

export const ISTAT = {
  pending: { label: 'Pending', cls: 'st-amber' },
  paid: { label: 'Paid', cls: 'st-green' },
  overdue: { label: 'Overdue', cls: 'st-red' },
};

export const PRIO = {
  high: { label: 'High', color: '#C2432F' },
  med: { label: 'Medium', color: '#C98A12' },
  low: { label: 'Low', color: '#0E7A47' },
};

export const MONTHS = (() => {
  const a = [], d = new Date();
  for (let i = 11; i >= 0; i--) {
    const m = new Date(d.getFullYear(), d.getMonth() - i, 1);
    a.push(m.toLocaleDateString('en-US', { month: 'short' }));
  }
  return a;
})();

export const EARN = [1900, 2400, 2100, 2900, 2600, 3100, 2800, 3400, 3050, 3700, 3300, 4120];

export const SEED_CLIENTS = [
  { id: 'c1', name: 'Amara Okafor', company: 'Bloom Beauty Co.', email: 'amara@bloombeauty.co', phone: '+1 415 555 0132', status: 'active', since: addDays(-140) },
  { id: 'c2', name: 'Daniel Reyes', company: 'Northwind Analytics', email: 'd.reyes@northwind.io', phone: '+1 628 555 0117', status: 'active', since: addDays(-210) },
  { id: 'c3', name: 'Priya Sharma', company: 'Leaf & Loom', email: 'priya@leafandloom.com', phone: '+44 20 7946 0321', status: 'active', since: addDays(-75) },
  { id: 'c4', name: 'Tomás Ferreira', company: 'Studio Mesa', email: 'tomas@studiomesa.br', phone: '+55 11 9555 2042', status: 'idle', since: addDays(-190) },
  { id: 'c5', name: 'Hannah Bergström', company: 'Nordic Fit', email: 'hannah@nordicfit.se', phone: '+46 8 555 1290', status: 'active', since: addDays(-50) },
  { id: 'c6', name: 'Marcus Cole', company: 'Cole Property Group', email: 'marcus@coleproperty.com', phone: '+1 312 555 0874', status: 'idle', since: addDays(-120) },
];

export const SEED_PROJECTS = [
  { id: 'p1', title: 'Brand refresh & identity system', clientId: 'c1', status: 'in_progress', budget: 3200, deadline: addDays(12) },
  { id: 'p2', title: 'Analytics dashboard UI', clientId: 'c2', status: 'in_progress', budget: 4800, deadline: addDays(25) },
  { id: 'p3', title: 'E-commerce storefront redesign', clientId: 'c3', status: 'in_progress', budget: 2600, deadline: addDays(6) },
  { id: 'p4', title: 'Portfolio site build', clientId: 'c4', status: 'completed', budget: 1800, deadline: addDays(-10), progress: 100 },
  { id: 'p5', title: 'Landing pages — spring campaign', clientId: 'c5', status: 'on_hold', budget: 1500, deadline: addDays(30), progress: 35 },
  { id: 'p6', title: 'Booking flow redesign', clientId: 'c6', status: 'in_progress', budget: 2900, deadline: addDays(18) },
  { id: 'p7', title: 'Packaging label artwork', clientId: 'c1', status: 'completed', budget: 900, deadline: addDays(-25), progress: 100 },
];

export const SEED_TASKS = [
  { id: 't1', title: 'Present moodboard round 2', projectId: 'p1', status: 'todo', prio: 'high', due: addDays(2) },
  { id: 't2', title: 'Refine logo variations', projectId: 'p1', status: 'doing', prio: 'high', due: addDays(1) },
  { id: 't3', title: 'Collect brand audit notes', projectId: 'p1', status: 'done', prio: 'med', due: addDays(-3) },
  { id: 't4', title: 'Design social media templates', projectId: 'p1', status: 'todo', prio: 'med', due: addDays(5) },
  { id: 't5', title: 'Build chart components', projectId: 'p2', status: 'doing', prio: 'med', due: addDays(4) },
  { id: 't6', title: 'Set up design tokens', projectId: 'p2', status: 'done', prio: 'low', due: addDays(-6) },
  { id: 't7', title: 'Wireframe checkout flow', projectId: 'p3', status: 'todo', prio: 'high', due: addDays(1) },
  { id: 't8', title: 'Product page hero design', projectId: 'p3', status: 'doing', prio: 'high', due: addDays(2) },
  { id: 't9', title: 'Responsive QA pass', projectId: 'p3', status: 'todo', prio: 'low', due: addDays(6) },
  { id: 't10', title: 'Booking calendar UI', projectId: 'p6', status: 'doing', prio: 'med', due: addDays(3) },
  { id: 't11', title: 'Email confirmation flow', projectId: 'p6', status: 'todo', prio: 'med', due: addDays(8) },
  { id: 't12', title: 'Send monthly invoice to Northwind', projectId: 'p2', status: 'todo', prio: 'high', due: addDays(0) },
  { id: 't13', title: 'Reply to Hannah about landing copy', projectId: 'p5', status: 'todo', prio: 'med', due: addDays(0) },
  { id: 't14', title: 'Update portfolio case study', projectId: 'p4', status: 'done', prio: 'low', due: addDays(-4) },
  { id: 't15', title: 'Final handoff documentation', projectId: 'p4', status: 'done', prio: 'med', due: addDays(-9) },
];

export const SEED_INVOICES = [
  { id: 'i1', number: 'INV-2026-001', clientId: 'c1', projectId: 'p1', issued: addDays(-12), due: addDays(2), status: 'paid', items: [{ d: 'Logo exploration — 3 concepts', q: 1, r: 650 }, { d: 'Brand guidelines document', q: 1, r: 500 }], notes: 'Great working with you on round two!' },
  { id: 'i2', number: 'INV-2026-002', clientId: 'c2', projectId: 'p2', issued: addDays(-14), due: addDays(0), status: 'pending', items: [{ d: 'Dashboard UI — sprint 2', q: 16, r: 100 }], notes: '' },
  { id: 'i3', number: 'INV-2026-003', clientId: 'c4', projectId: 'p4', issued: addDays(-28), due: addDays(-14), status: 'paid', items: [{ d: 'Portfolio site design & build', q: 1, r: 1800 }], notes: '' },
  { id: 'i4', number: 'INV-2026-004', clientId: 'c3', projectId: 'p3', issued: addDays(-8), due: addDays(6), status: 'pending', items: [{ d: 'Storefront design — phase 1', q: 9, r: 100 }], notes: '' },
  { id: 'i5', number: 'INV-2026-005', clientId: 'c6', projectId: 'p6', issued: addDays(-26), due: addDays(-12), status: 'overdue', items: [{ d: 'Booking flow research & wireframes', q: 14, r: 80 }, { d: 'Usability testing session', q: 1, r: 330 }], notes: 'Payment within 7 days, please.' },
  { id: 'i6', number: 'INV-2026-006', clientId: 'c5', projectId: 'p5', issued: addDays(-3), due: addDays(11), status: 'pending', items: [{ d: 'Landing page — hero section', q: 1, r: 750 }], notes: '' },
  { id: 'i7', number: 'INV-2026-007', clientId: 'c1', projectId: 'p7', issued: addDays(-45), due: addDays(-31), status: 'paid', items: [{ d: 'Packaging label artwork', q: 1, r: 640 }], notes: '' },
];

export const SEED_NOTIFS = [
  { id: 'n1', icon: 'banknote', text: 'Payment received — INV-2026-001 from Bloom Beauty Co. ($1,150)', time: '2h ago', read: false },
  { id: 'n2', icon: 'clock', text: '“Wireframe checkout flow” is due tomorrow.', time: '6h ago', read: false },
  { id: 'n3', icon: 'file', text: 'INV-2026-005 from Cole Property Group is overdue.', time: 'Yesterday', read: true },
  { id: 'n4', icon: 'tasks', text: 'You completed “Set up design tokens”. Nice work.', time: '2 days ago', read: true },
];
