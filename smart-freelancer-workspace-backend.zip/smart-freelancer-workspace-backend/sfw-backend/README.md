# Smart Freelancer Workspace API

Spring Boot 3.3 / Java 17 / MySQL / JWT.

Proposal-aligned model: User -> Client -> Project -> Task, and Project -> Invoice.

## API
- POST /api/auth/register
- POST /api/auth/login
- CRUD /api/clients
- CRUD /api/projects?clientId=...
- CRUD /api/tasks?projectId=...
- GET /api/invoices
- POST /api/invoices?clientId=...&projectId=...
- PUT /api/invoices/{id}/status?value=paid
- DELETE /api/invoices/{id}

All non-auth endpoints require `Authorization: Bearer <token>`.

## Run
Set `DB_USERNAME`, `DB_PASSWORD`, and `JWT_SECRET` as environment variables if your MySQL credentials differ from the defaults, then run with Maven.
