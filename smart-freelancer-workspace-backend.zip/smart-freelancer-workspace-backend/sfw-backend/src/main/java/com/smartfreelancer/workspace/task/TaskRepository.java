package com.smartfreelancer.workspace.task;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.*;

public interface TaskRepository extends JpaRepository<Task, Long> {
    List<Task> findAllByProjectClientUserId(Long userId);

    Optional<Task> findByIdAndProjectClientUserId(Long id, Long userId);
}
