package com.smartfreelancer.workspace.project;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.*;

public interface ProjectRepository extends JpaRepository<Project, Long> {
    List<Project> findAllByClientUserId(Long userId);

    Optional<Project> findByIdAndClientUserId(Long id, Long userId);
}
