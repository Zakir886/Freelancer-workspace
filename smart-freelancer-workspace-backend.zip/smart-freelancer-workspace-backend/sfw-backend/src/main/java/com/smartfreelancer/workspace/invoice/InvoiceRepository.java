package com.smartfreelancer.workspace.invoice;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.*;

public interface InvoiceRepository extends JpaRepository<Invoice, Long> {
    List<Invoice> findAllByClientUserId(Long userId);

    Optional<Invoice> findByIdAndClientUserId(Long id, Long userId);
}
