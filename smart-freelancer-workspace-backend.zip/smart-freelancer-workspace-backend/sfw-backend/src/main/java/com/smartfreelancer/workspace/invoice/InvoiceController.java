package com.smartfreelancer.workspace.invoice;

import com.smartfreelancer.workspace.client.*;
import com.smartfreelancer.workspace.project.*;
import com.smartfreelancer.workspace.user.*;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/invoices")
public class InvoiceController {
    final InvoiceRepository repo;
    final ClientRepository clients;
    final ProjectRepository projects;
    final UserRepository users;

    InvoiceController(InvoiceRepository r, ClientRepository c, ProjectRepository p, UserRepository u) {
        repo = r;
        clients = c;
        projects = p;
        users = u;
    }

    User me(Authentication a) {
        return users.findByEmail(a.getName()).orElseThrow();
    }

    @GetMapping
    List<Invoice> all(Authentication a) {
        return repo.findAllByClientUserId(me(a).getId());
    }

    @PostMapping
    Invoice create(@RequestBody Invoice i, @RequestParam Long clientId, @RequestParam Long projectId, Authentication a) {
        User u = me(a);
        Client c = clients.findByIdAndUserId(clientId, u.getId()).orElseThrow();
        Project p = projects.findByIdAndClientUserId(projectId, u.getId()).orElseThrow();
        if (!p.getClient().getId().equals(c.getId()))
            throw new IllegalArgumentException("Project does not belong to client");
        i.id = null;
        i.setClient(c);
        i.setProject(p);
        if (i.getNumber() == null || i.getNumber().isBlank()) i.setNumber("INV-" + System.currentTimeMillis());
        return repo.save(i);
    }

    @PutMapping("/{id}/status")
    Invoice status(@PathVariable Long id, @RequestParam String value, Authentication a) {
        Invoice i = repo.findByIdAndClientUserId(id, me(a).getId()).orElseThrow();
        i.setStatus(value);
        return repo.save(i);
    }

    @DeleteMapping("/{id}")
    void delete(@PathVariable Long id, Authentication a) {
        repo.findByIdAndClientUserId(id, me(a).getId()).ifPresent(repo::delete);
    }
}
