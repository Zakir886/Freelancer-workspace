package com.smartfreelancer.workspace.task;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smartfreelancer.workspace.project.Project;
import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name = "tasks")
public class Task {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;
    @ManyToOne(optional = false)
    @JsonIgnore
    Project project;
    @Column(nullable = false)
    String title;
    @Column(nullable = false)
    String status = "todo";
    String priority = "med";
    LocalDate due;

    public Long getId() {
        return id;
    }

    public Project getProject() {
        return project;
    }

    public void setProject(Project p) {
        project = p;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String v) {
        title = v;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String v) {
        status = v;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String v) {
        priority = v;
    }

    public LocalDate getDue() {
        return due;
    }

    public void setDue(LocalDate v) {
        due = v;
    }
}
