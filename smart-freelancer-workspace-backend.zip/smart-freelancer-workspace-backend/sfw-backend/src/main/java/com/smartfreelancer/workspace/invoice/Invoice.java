package com.smartfreelancer.workspace.invoice;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smartfreelancer.workspace.client.Client;
import com.smartfreelancer.workspace.project.Project;
import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

@Entity
@Table(name = "invoices")
public class Invoice {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;
    @Column(nullable = false, unique = true)
    String number;
    @ManyToOne(optional = false)
    @JsonIgnore
    Client client;
    @ManyToOne(optional = false)
    @JsonIgnore
    Project project;
    LocalDate issued, due;
    String status = "pending";
    String notes;
    @ElementCollection
    @CollectionTable(name = "invoice_items", joinColumns = @JoinColumn(name = "invoice_id"))
    List<InvoiceItem> items = new ArrayList<>();

    public Long getId() {
        return id;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String v) {
        number = v;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client v) {
        client = v;
    }

    public Project getProject() {
        return project;
    }

    public void setProject(Project v) {
        project = v;
    }

    public LocalDate getIssued() {
        return issued;
    }

    public void setIssued(LocalDate v) {
        issued = v;
    }

    public LocalDate getDue() {
        return due;
    }

    public void setDue(LocalDate v) {
        due = v;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String v) {
        status = v;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String v) {
        notes = v;
    }

    public List<InvoiceItem> getItems() {
        return items;
    }

    public void setItems(List<InvoiceItem> v) {
        items = v;
    }
}

@Embeddable
class InvoiceItem {
    String description;
    Integer quantity;
    BigDecimal rate;

    public String getDescription() {
        return description;
    }

    public void setDescription(String v) {
        description = v;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer v) {
        quantity = v;
    }

    public BigDecimal getRate() {
        return rate;
    }

    public void setRate(BigDecimal v) {
        rate = v;
    }
}
