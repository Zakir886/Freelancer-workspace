package com.smartfreelancer.workspace.project;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.smartfreelancer.workspace.client.Client;
import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "projects")
public class Project {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;
    @ManyToOne(optional = false)
    @JsonIgnore
    Client client;
    @Column(nullable = false)
    String title;
    @Column(length = 2000)
    String description;
    @Column(nullable = false)
    String status = "in_progress";
    BigDecimal budget;
    LocalDate deadline;

    public Long getId() {
        return id;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client c) {
        client = c;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String v) {
        title = v;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String v) {
        description = v;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String v) {
        status = v;
    }

    public BigDecimal getBudget() {
        return budget;
    }

    public void setBudget(BigDecimal v) {
        budget = v;
    }

    public LocalDate getDeadline() {
        return deadline;
    }

    public void setDeadline(LocalDate v) {
        deadline = v;
    }
}
