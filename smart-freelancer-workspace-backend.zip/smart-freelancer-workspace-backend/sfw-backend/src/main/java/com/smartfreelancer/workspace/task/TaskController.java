package com.smartfreelancer.workspace.task;

import com.smartfreelancer.workspace.project.*;
import com.smartfreelancer.workspace.user.*;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/tasks")
public class TaskController {
    final TaskRepository repo;
    final ProjectRepository projects;
    final UserRepository users;

    TaskController(TaskRepository r, ProjectRepository p, UserRepository u) {
        repo = r;
        projects = p;
        users = u;
    }

    User me(Authentication a) {
        return users.findByEmail(a.getName()).orElseThrow();
    }

    @GetMapping
    List<Task> all(Authentication a) {
        return repo.findAllByProjectClientUserId(me(a).getId());
    }

    @PostMapping
    Task create(@RequestBody Task t, @RequestParam Long projectId, Authentication a) {
        t.id = null;
        t.setProject(projects.findByIdAndClientUserId(projectId, me(a).getId()).orElseThrow());
        return repo.save(t);
    }

    @PutMapping("/{id}")
    Task update(@PathVariable Long id, @RequestBody Task t, @RequestParam Long projectId, Authentication a) {
        Task x = repo.findByIdAndProjectClientUserId(id, me(a).getId()).orElseThrow();
        x.setProject(projects.findByIdAndClientUserId(projectId, me(a).getId()).orElseThrow());
        x.setTitle(t.getTitle());
        x.setStatus(t.getStatus());
        x.setPriority(t.getPriority());
        x.setDue(t.getDue());
        return repo.save(x);
    }

    @DeleteMapping("/{id}")
    void delete(@PathVariable Long id, Authentication a) {
        repo.findByIdAndProjectClientUserId(id, me(a).getId()).ifPresent(repo::delete);
    }
}
