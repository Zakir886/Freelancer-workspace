package com.smartfreelancer.workspace;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartFreelancerWorkspaceApplication {
    public static void main(String[] args) {
        SpringApplication.run(SmartFreelancerWorkspaceApplication.class, args);
    }
}
