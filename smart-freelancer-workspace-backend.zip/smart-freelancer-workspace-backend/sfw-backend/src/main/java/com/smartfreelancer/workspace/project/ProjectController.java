package com.smartfreelancer.workspace.project;

import com.smartfreelancer.workspace.client.*;
import com.smartfreelancer.workspace.user.*;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/projects")
public class ProjectController {
    final ProjectRepository repo;
    final ClientRepository clients;
    final UserRepository users;

    ProjectController(ProjectRepository r, ClientRepository c, UserRepository u) {
        repo = r;
        clients = c;
        users = u;
    }

    User me(Authentication a) {
        return users.findByEmail(a.getName()).orElseThrow();
    }

    @GetMapping
    List<Project> all(Authentication a) {
        return repo.findAllByClientUserId(me(a).getId());
    }

    @PostMapping
    Project create(@RequestBody Project p, @RequestParam Long clientId, Authentication a) {
        p.id = null;
        p.setClient(clients.findByIdAndUserId(clientId, me(a).getId()).orElseThrow());
        return repo.save(p);
    }

    @PutMapping("/{id}")
    Project update(@PathVariable Long id, @RequestBody Project p, @RequestParam Long clientId, Authentication a) {
        Project x = repo.findByIdAndClientUserId(id, me(a).getId()).orElseThrow();
        x.setClient(clients.findByIdAndUserId(clientId, me(a).getId()).orElseThrow());
        x.setTitle(p.getTitle());
        x.setDescription(p.getDescription());
        x.setStatus(p.getStatus());
        x.setBudget(p.getBudget());
        x.setDeadline(p.getDeadline());
        return repo.save(x);
    }

    @DeleteMapping("/{id}")
    void delete(@PathVariable Long id, Authentication a) {
        repo.findByIdAndClientUserId(id, me(a).getId()).ifPresent(repo::delete);
    }
}
