package com.smartfreelancer.workspace.auth;

import com.smartfreelancer.workspace.config.JwtService;
import com.smartfreelancer.workspace.user.*;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final UserRepository users;
    private final PasswordEncoder encoder;
    private final JwtService jwt;

    public AuthController(
            UserRepository users,
            PasswordEncoder encoder,
            JwtService jwt
    ) {
        this.users = users;
        this.encoder = encoder;
        this.jwt = jwt;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(
            @Valid @RequestBody AuthDtos.RegisterRequest r
    ) {
        if (users.existsByEmail(r.email())) {
            return ResponseEntity
                    .status(HttpStatus.CONFLICT)
                    .body("Email already registered");
        }

        User u = new User();
        u.setName(r.name());
        u.setEmail(r.email().toLowerCase());
        u.setPassword(encoder.encode(r.password()));

        users.save(u);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(
                        new AuthDtos.AuthResponse(
                                jwt.generate(u.getEmail()),
                                u.getId(),
                                u.getName(),
                                u.getEmail()
                        )
                );
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(
            @Valid @RequestBody AuthDtos.LoginRequest r
    ) {
        return users.findByEmail(r.email().toLowerCase())
                .filter(u -> encoder.matches(
                        r.password(),
                        u.getPassword()
                ))
                .<ResponseEntity<?>>map(u ->
                        ResponseEntity.ok(
                                new AuthDtos.AuthResponse(
                                        jwt.generate(u.getEmail()),
                                        u.getId(),
                                        u.getName(),
                                        u.getEmail()
                                )
                        )
                )
                .orElseGet(() ->
                        ResponseEntity
                                .status(HttpStatus.UNAUTHORIZED)
                                .body("Invalid email or password")
                );
    }
}