package com.smartfreelancer.workspace.client;

import com.smartfreelancer.workspace.user.*;
import org.springframework.security.core.*;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/clients")
public class ClientController {
    final ClientRepository repo;
    final UserRepository users;

    ClientController(ClientRepository r, UserRepository u) {
        repo = r;
        users = u;
    }

    User me(Authentication a) {
        return users.findByEmail(a.getName()).orElseThrow();
    }

    @GetMapping
    List<Client> all(Authentication a) {
        return repo.findAllByUserId(me(a).getId());
    }

    @PostMapping
    Client create(@RequestBody Client c, Authentication a) {
        c.setUser(me(a));
        c.id = null;
        return repo.save(c);
    }

    @PutMapping("/{id}")
    Client update(@PathVariable Long id, @RequestBody Client c, Authentication a) {
        Client x = repo.findByIdAndUserId(id, me(a).getId()).orElseThrow();
        x.setName(c.getName());
        x.setCompany(c.getCompany());
        x.setEmail(c.getEmail());
        x.setPhone(c.getPhone());
        x.setStatus(c.getStatus());
        return repo.save(x);
    }

    @DeleteMapping("/{id}")
    void delete(@PathVariable Long id, Authentication a) {
        repo.findByIdAndUserId(id, me(a).getId()).ifPresent(repo::delete);
    }
}
