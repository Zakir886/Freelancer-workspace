package com.smartfreelancer.workspace.client;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.*;

public interface ClientRepository extends JpaRepository<Client, Long> {
    List<Client> findAllByUserId(Long userId);

    Optional<Client> findByIdAndUserId(Long id, Long userId);
}
